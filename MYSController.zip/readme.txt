MYSController 0.1.2.282: MySensors lib 1.5
MYSController 1.0.0beta: MySensors lib 2.0.0 (dev). Compatibility with lib 1.5 not tested.

Have fun,
tekka
